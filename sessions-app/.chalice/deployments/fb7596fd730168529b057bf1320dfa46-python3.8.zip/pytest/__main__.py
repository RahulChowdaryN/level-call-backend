"""
pytest entry point
"""
import pytest

if __name__ == "__main__":
    raise SystemExit(pytest.console_main())
