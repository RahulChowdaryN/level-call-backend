from boto3.dynamodb.conditions import Attr
from schema import Schema, Use
from datetime import datetime
DEFAULT_USERNAME = 'default'


class DynamoDBFeedback():
    def __init__(self, table_resource):
        self._table = table_resource

    def list_all_items(self):
        response = self._table.scan()
        return response['Items']

    def list_items_by_course_id(self, course_id):
        print("course", course_id)
        response = self._table.scan(
            FilterExpression=Attr('course_id').eq(course_id),
            ProjectionExpression='course_id,start_time,#dur,session_id,session_name,students,tutor,#st',
            ExpressionAttributeNames={'#dur': 'duration','#st':'status'}
        )
        return response['Items']

    def add_item(self, session_record):
        self._table.put_item(
            Item=session_record

        )
        return session_record['session_id']

    def list_items_mail(self, session_id_list):
        response = self._table.scan(

            FilterExpression=Attr('session_id').is_in(session_id_list) & Attr('start_time').gte(str(datetime.utcnow())),
            ProjectionExpression='course_id,#dr,session_name,start_time,students,tutor,#st',
            ExpressionAttributeNames={'#dr': 'duration','#st':'status'}
        )
        print("response of mails", response)

        return response['Items']


    def list_items_course(self, session_id_list,course_id):
        response = self._table.scan(
            FilterExpression=Attr('session_id').is_in(session_id_list) & Attr('course_id').eq(course_id),#& Attr('start_time').gte(str(datetime.utcnow())),
            ProjectionExpression='course_id,#dr,session_name,start_time,students,tutor,#st',
            ExpressionAttributeNames={'#dr': 'duration','#st':'status'}
        )
        print("response of mails", response)

        print(response)

        return response['Items']

    def validate_token(self, token):
        response = self._table.scan(
            FilterExpression=Attr('token').eq(token),
            ProjectionExpression='session_id'
        )

        return response

    def get_item(self, session_id):
        response = self._table.get_item(
            Key={
                'session_id': session_id,
            },
            ProjectionExpression='course_id,start_time,tutor,#dur,session_name,students,#st',
            ExpressionAttributeNames={'#dur': 'duration','#st':'status'}

        )

        if response.get('Item', False):
            return response['Item']
        return {}

    def delete_item(self, session_id):
        self._table.delete_item(
            Key={
                'session_id': session_id
            }
        )

        return

    def update_item(self, body):
        # We could also use update_item() with an UpdateExpression.

        # item = self.get_item(body['session_id'])
        #
        # if body.get('start_time', False):
        #     item['start_time'] = body['start_time']
        #
        # if body.get('course_id', False):
        #     item['course_id'] = body['course_id']
        #
        # if body.get('duration', False):
        #     item['duration'] = body['duration']
        #
        # if body.get('end_time', False):
        #     item['end_time'] = body['end_time']

        self._table.put_item(Item=body)


session_schema = Schema({'name': Use(str), 'course_id': Use(int), 'start_time': Use(str), "tutor": Use(dict),
                         "nested": Schema({"email": Use(str)})})


