import os
from uuid import uuid4
from boto3 import resource, client
from chalice import Chalice, AuthResponse,CustomAuthorizer,CORSConfig
from chalice import CustomAuthorizer
from chalicelib.feedback_app import feedback_db
from chalicelib.audit_app import audit_db
from chalicelib.roles import roles_db

from datetime import datetime
import json


app = Chalice(app_name='audit-feedback')

invokeLambda = client("lambda", region_name="us-east-2")
cors_config = CORSConfig(
    allow_origin='*',
    max_age=600,
    expose_headers=['X-Special-Header'],
    allow_credentials=False
)

app.debug = True
_USER_AUDIT_DB = None
_SESSION_AUDIT_DB = None
_FEEDBACK_DB = None
_USER_ROLES_DB = None
_SESSION_ROLES_DB = None
_USER_ROLES = None
_SESSION_ROLES = None

@app.route('/')
def index():
    return {'hello': 'world'}

authorizer = CustomAuthorizer(
    'MyCustomAuth', header='Authorization',
    authorizer_uri=('arn:aws:apigateway:ap-south-1:lambda:path/2015-03-31'
                    '/functions/arn:aws:lambda:us-east-2:886064876783:function:sessions-app-dev-jwt_auth/invocations'))


@app.route('/api/custom-auth', methods=['GET'], authorizer=authorizer)
def authenticated():
    return {"success": True}


def get_feedback_db():
    global _FEEDBACK_DB
    if _FEEDBACK_DB is None:
        _FEEDBACK_DB = feedback_db.DynamoDBFeedback(
            resource('dynamodb').Table(
                os.environ['FEEDBACK_TABLE_NAME'])
        )
    return _FEEDBACK_DB


def get_session_audit_db():
    global _SESSION_AUDIT_DB
    if _SESSION_AUDIT_DB is None:
        _SESSION_AUDIT_DB = audit_db.DynamoDBAudit(
            resource('dynamodb').Table(
                os.environ['SESSION_AUDIT_TABLE_NAME'])
        )
    return _SESSION_AUDIT_DB


def get_user_audit_db():
    global _USER_AUDIT_DB
    if _USER_AUDIT_DB is None:
        _USER_AUDIT_DB = audit_db.DynamoDBAudit(
            resource('dynamodb').Table(
                os.environ['USER_AUDIT_TABLE_NAME'])
        )
    return _USER_AUDIT_DB


def get_session_roles_db():
    """
    connects to session roles table. global variable
    :return: connection

    """
    app.log.info('connecting to session-roles table')
    global _ROLES_DB
    if _ROLES_DB is None:
        _ROLES_DB = roles_db.DynamoDBRoles(
            resource('dynamodb').Table(
                os.environ['SESSION-ROLES_TABLE_NAME'])
        )
    app.log.info('connected to session-roles table')
    return _ROLES_DB


def get_user_roles_db():
    """
    connects to session roles table. global variable
    :return: connection

    """
    app.log.info('connecting to user-roles table')
    global _USER_ROLES_DB
    if _USER_ROLES_DB is None:
        _USER_ROLES_DB = roles_db.DynamoDBRoles(
            resource('dynamodb').Table(
                os.environ['USER-ROLES_TABLE_NAME'])
        )
    app.log.info('connected to session-roles table')
    return _USER_ROLES_DB


def get_authorized_session_id(current_request):
    print("current request session_id", current_request.context)
    return current_request.context['authorizer']['session_id']


def get_authorized_email(current_request):
    print("current request email", current_request.context)
    return current_request.context['authorizer']['principalId']


@app.route('/api/audit/session/{session_id}', methods=['GET'], cors=cors_config)
def get_session_audit(session_id):
    app.log.info(f"getting session audit event for sessionId {session_id}")
    response = get_session_audit_db().get_session_item(session_id)

    return response


@app.route('/api/audit/user/{user_id}', methods=['GET'], cors=cors_config)
def get_user_audit(user_id):
    app.log.info(f"getting user audit event for userId {user_id}")
    response = get_user_audit_db().get_user_item(str(user_id))

    return response


@app.lambda_function(name='UserAuditFunction')
def user_audit_lambda_function(event, context):
    # Anything you want here.
    app.log.info(f"user audit entry {event} {context}")
    event['uid'] = str(uuid4())

    get_user_audit_db().add_item(event)
    return {"message": "updated"}


@app.lambda_function(name='SessionAuditFunction')
def session_audit_lambda_function(event, context):
    app.log.info(f"session audit entry {event} {context}")
    # Anything you want here.
    event['uid'] = str(uuid4())
    get_session_audit_db().add_item(event)
    return {"message": "updated"}


def user_roles():
    global _USER_ROLES
    if _USER_ROLES is None:
        app.log.info("cache miss for user roles, connecting to db")
        _USER_ROLES = get_user_roles_db().list_all_items()
    return _USER_ROLES


def session_roles():
    global _SESSION_ROLES
    if _SESSION_ROLES is None:
        app.log.info("cache miss for session roles, connecting to db")
        _SESSION_ROLES = get_session_roles_db().list_all_items()
    return _SESSION_ROLES


@app.route('/api/session/roles', methods=['GET'], cors=cors_config)
def get_session_roles():

    roles_data = session_roles()

    return roles_data


@app.route('/api/session/roles', methods=['POST'], cors=cors_config)
def update_session_roles():
    body = app.current_request.json_body

    if not body:
        return {'message': 'empty body, missing required details'}
    all_roles_list = []
    for each_role in body:
        all_roles_list.append(each_role)
    response = get_session_roles_db().add_item(all_roles_list)

    return {"message": response}


@app.route('/api/user/roles', methods=['GET'], cors=cors_config)
def get_user_roles():

    roles_data = user_roles()

    return roles_data


@app.route('/api/user/roles', methods=['POST'], cors=cors_config)
def update_user_roles():
    body = app.current_request.json_body

    if not body:
        return {'message': 'empty body, missing required details'}
    all_roles_list = []
    for each_role in body:
        all_roles_list.append(each_role)
    response = get_user_roles_db().add_item(all_roles_list)

    return {"message": response}


@app.route('/api/test', methods=['POST'], cors=cors_config)
def test_user_roles():
    body = app.current_request.json_body

    body['uid'] = str(uuid4())

    response = get_session_audit_db().add_item(body)
    return {"message": "updated"}



